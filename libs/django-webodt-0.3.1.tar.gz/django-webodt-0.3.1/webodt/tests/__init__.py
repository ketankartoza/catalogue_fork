# -*- coding: utf8 -*-
from webodt.tests.base import *
from webodt.tests.shortcuts import *
from webodt.tests.cache import *
from webodt.tests.preprocessors import *
